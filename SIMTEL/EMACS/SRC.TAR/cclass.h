#define c_SIMPLE 0x01	/* 1 screen char */
#define c_CWORD  0x02	/* alphanumeric or _ */	
#define c_WHITE  0x04
#define c_TAB    0x08
#define c_LOWC   0x10
#define c_ALPHA  0x20
#define c_DIGIT  0x40
#define c_FENCE  0x80



