crlf()
{
	static char *cr = "\r\n";
	write(1,cr,2);
}
